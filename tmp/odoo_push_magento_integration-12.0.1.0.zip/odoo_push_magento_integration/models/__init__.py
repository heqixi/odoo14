# -*- coding: utf-8 -*-

from . import magento
from . import product
from . import stock
