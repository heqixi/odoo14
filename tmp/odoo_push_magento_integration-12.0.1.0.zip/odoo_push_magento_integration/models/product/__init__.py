from . import odoo_product
