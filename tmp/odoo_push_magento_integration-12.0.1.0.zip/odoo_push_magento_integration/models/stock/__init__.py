from . import product
from . import res_partner
from . import stock_inventory
from . import stock_location
from . import stock_picking
